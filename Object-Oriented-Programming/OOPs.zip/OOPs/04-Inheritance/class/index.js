// class (Base Class)
class BankAccount {
    // properties
    customerName ; 
    accountNumber ; 
    balance ; 

    // constructor
    constructor(customerName, accountNumber, balance = 0){
        this.customerName = customerName;
        this.accountNumber = accountNumber ; 
        this.balance = balance ;
    }

    // methods
    deposit(amount = 0){
        this.balance += amount ;
    }

    withdraw(amount = 0){
        this.balance -= amount ;
    }
};

// Saving Account (Derived class)
class SavingAccount extends BankAccount{
    transactionLimit = 50000;

    constructor(customerName, accountNumber, balance = 0){
        // call the parent constructor class
        super(customerName, accountNumber, balance);
    }

    displayTransactionLimit(){
        console.log("Transaction Limit : ",this.transactionLimit);
    }
};

// objects
const rakeshAccount = new SavingAccount('Rakesh K','123456',2000);
const johnAccount = new BankAccount('John Carter','456789');

// methods calling
rakeshAccount.withdraw(500);
johnAccount.deposit(3500);

// results
console.log(rakeshAccount);
console.log(johnAccount);

rakeshAccount.displayTransactionLimit();
