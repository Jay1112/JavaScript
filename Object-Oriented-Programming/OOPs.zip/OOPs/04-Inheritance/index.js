// constructor function
function BankAccount(customerName = '', accountNumber ,initialBalance = 0){
    
    /* properties */
    this.customerName  = customerName   ; 
    this.accountNumber = accountNumber  ;
    this.balance       = initialBalance ;
}

BankAccount.prototype.deposit = function(amount){
    this.balance += amount;
}

BankAccount.prototype.withdraw = function(amount){
    this.balance -= amount;
}

// Saving Account
function SavingAccount(customerName = '', accountNumber ,initialBalance = 0){
    // constructor linking
    BankAccount.call(this,customerName,accountNumber,initialBalance);
    this.transactionLimit = 10000;
}
// Prototype linking
SavingAccount.prototype = Object.create(BankAccount.prototype);

SavingAccount.prototype.displayTransactionLimit = function(){
    console.log("Transaction Limit : ",this.transactionLimit);
}

// objects
const rakeshAccount = new SavingAccount('Rakesh K','123456',1000);
const johnAccount = new BankAccount('John Carter','456789');

// methods calling
rakeshAccount.withdraw(500);
johnAccount.deposit(1500);

// results
console.log(rakeshAccount);
console.log(johnAccount);

rakeshAccount.displayTransactionLimit();