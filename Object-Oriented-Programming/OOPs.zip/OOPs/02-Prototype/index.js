// constructor function
function BankAccount(customerName = '', accountNumber ,initialBalance = 0){
    
    /* properties */
    this.customerName  = customerName   ; 
    this.accountNumber = accountNumber  ;
    this.balance       = initialBalance ;

    // To share the common methods among all the objects we use prototype, 
    // there will be no extra memory for each object
    BankAccount.prototype.deposit = function(amount){
        this.balance += amount;
    }

    BankAccount.prototype.withdraw = function(amount){
        this.balance -= amount;
    }
}

// objects
const rakeshAccount = new BankAccount('Rakesh K','123456',1000);
const johnAccount = new BankAccount('John Carter','456789');

// methods calling
rakeshAccount.withdraw(500);
johnAccount.deposit(1500);

// results
console.log(rakeshAccount);
console.log(johnAccount);