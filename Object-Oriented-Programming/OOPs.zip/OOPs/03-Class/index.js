// class
class BankAccount {
    // properties
    customerName ; 
    accountNumber ; 
    balance ; 

    // constructor
    constructor(customerName, accountNumber, balance = 0){
        this.customerName = customerName;
        this.accountNumber = accountNumber ; 
        this.balance = balance ;
    }

    // methods
    deposit(amount = 0){
        this.balance += amount ;
    }

    withdraw(amount = 0){
        this.balance -= amount ;
    }
};

// objects
const rakeshAccount = new BankAccount('Rakesh K','123456',2000);
const johnAccount = new BankAccount('John Carter','456789');

// methods calling
rakeshAccount.withdraw(500);
johnAccount.deposit(3500);

// results
console.log(rakeshAccount);
console.log(johnAccount);