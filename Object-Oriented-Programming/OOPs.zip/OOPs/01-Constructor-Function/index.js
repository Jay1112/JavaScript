// constructor function
function BankAccount(customerName = '', accountNumber ,initialBalance = 0){
    
    /* properties */
    this.customerName  = customerName   ; 
    this.accountNumber = accountNumber  ;
    this.balance       = initialBalance ;

    /* methods := method will be kept some memory for each object. */

    // deposit 
    this.deposit = function(amount = 0){
        this.balance += amount ;
    }

    // withdraw
    this.withdraw = (amount = 0) => {
        this.balance -= amount ;
    }

}

// objects
const rakeshAccount = new BankAccount('Rakesh K','123456',1000);
const johnAccount = new BankAccount('John Carter','456789');

// methods calling
rakeshAccount.withdraw(500);
johnAccount.deposit(1500);

// results
console.log(rakeshAccount);
console.log(johnAccount);