class User{
    static players = 0;
    constructor(name,age,income){
        this.name = name ; 
        this.age  = age ;
        this.income = income;
        User.players++;
    }

    static getNoOfPlayers(){
        return this.players;
    }

    static onlinePlayers(){
        console.log(`Online Players : ${this.getNoOfPlayers()}`);
    }

    static sortUsersByAge(user1,user2){
        return user1.age - user2.age ;
    }

    static sortUsersByIncome(user1,user2){
        return user1.income - user2.income ;
    }
};

const user1 = new User('John Doe' , 20, 2000);
const user2 = new User('Tuna lie' , 13, 3000);
const user3 = new User('Kan V'    , 17, 5000);

let users = [user1,user2,user3];

// Sorting By Age
users.sort(User.sortUsersByAge);
console.log(users);

// Sorting By Income
users.sort(User.sortUsersByIncome);
console.log(users);

// no.of players online
User.onlinePlayers()