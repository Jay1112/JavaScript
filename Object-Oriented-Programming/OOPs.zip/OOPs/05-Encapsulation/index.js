class BankAccount{
    // private properties
    _customer_name = ''; 
    #balance = 0;

    constructor(customer_name,balance){
        this.customer_name = customer_name;
        this.balance       = balance;
    }

    // getter method
    getCustomerName(){
        return this.customer_name;
    }

    // setter method
    setCustomerName(name){
        this.customer_name = name ; 
    }

    // ES6 getter
    get balance(){
        return this.#balance;
    }

    // ES6 setter
    set balance(amount){
        if(isNaN(amount)){
            throw new Error("Invalid Amount!!!");
        }
        try{
            this.#balance = parseInt(amount);
        }catch(err){
            console.log(err);
        }
    }

};

class SavingAccount extends BankAccount {
    // private method
    #printLoanMessage(){
        console.log("You have taken a loan.");
    }

    takeLoan(){
        this.#printLoanMessage();
    }
}

// Note : in derived class, we can not access base class private properties and methods.

const rakeshAccount = new SavingAccount("Rakesh V",300);
console.log(rakeshAccount.getCustomerName());
console.log(rakeshAccount.balance);
rakeshAccount.balance = 900;
console.log(rakeshAccount.balance);
rakeshAccount.takeLoan();